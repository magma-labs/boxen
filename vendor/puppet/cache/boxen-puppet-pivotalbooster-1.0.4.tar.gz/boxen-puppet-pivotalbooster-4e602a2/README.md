[![Build Status](https://travis-ci.org/boxen/puppet-pivotalbooster.png?branch=master)](https://travis-ci.org/boxen/puppet-pivotalbooster)
# PivotalBooster Puppet Module for Boxen

Installs PivotalBooster.  See http://pivotalbooster.com/

## Usage

```puppet
include pivotalbooster
```

## Required Puppet Modules

* `boxen`
