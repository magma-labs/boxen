# Tunnelblick Puppet Module for Boxen

[![Build Status](https://travis-ci.org/mattheath/puppet-tunnelblick.png?branch=master)](https://travis-ci.org/mattheath/puppet-tunnelblick)

## Usage

```puppet
include tunnelblick
include tunnelblick::beta
```

## Required Puppet Modules

`boxen`

## Developing

Write code.

Run `script/cibuild`.
